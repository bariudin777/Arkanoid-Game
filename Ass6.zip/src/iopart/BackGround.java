package iopart;


import collections.Sprite;

/**
 * The type Back ground.
 */
public abstract class BackGround implements Sprite {

    /**
     * Instantiates a new Back ground.
     */
    public BackGround() {
    }


}
